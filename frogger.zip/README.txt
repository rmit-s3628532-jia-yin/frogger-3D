All the SOIL source and header files are included in compilation because the SOIL library provided in the tutorial cannot be used on my Mac. So all the SOIL source files are included in Makefile. 

please use the following command to run the program:

./game road.png grass.jpg sand.jpg wood.jpg 